<?php
/**
 * @package formit
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/formitform.class.php');
class FormItForm_mysql extends FormItForm {}
?>