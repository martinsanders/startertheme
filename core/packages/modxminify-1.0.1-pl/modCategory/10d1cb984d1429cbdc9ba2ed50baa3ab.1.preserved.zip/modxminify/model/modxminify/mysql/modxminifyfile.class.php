<?php
/**
 * @package modxminify
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/modxminifyfile.class.php');
class modxMinifyFile_mysql extends modxMinifyFile {}
?>