<?php
/**
 * @package modxminify
 */
class modxMinifyGroup extends xPDOSimpleObject {}