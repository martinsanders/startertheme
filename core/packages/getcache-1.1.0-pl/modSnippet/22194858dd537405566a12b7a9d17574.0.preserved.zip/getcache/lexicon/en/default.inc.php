<?php
$_lang['refreshing_partition'] = "Refreshing cache partition [[+partition]]: ";
