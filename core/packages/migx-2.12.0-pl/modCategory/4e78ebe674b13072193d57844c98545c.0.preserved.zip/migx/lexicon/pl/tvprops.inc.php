﻿<?php
/**
 * migx
 *
 * @package migx
 * @language en
 */


$_lang['mig.tabs'] = 'Formularze danych';
$_lang['mig.columns'] = 'Kolumny';
$_lang['mig.btntext'] = 'Tekst zamiast "Dodaj" ';
$_lang['mig.previewurl'] = 'Podgląd Url';
$_lang['mig.jsonvarkey'] = 'Podgląd JsonVarKey';
$_lang['mig.configs'] = 'Konfiguracje';
$_lang['mig.autoResourceFolders'] = 'Opcja Auto Resource Folders';