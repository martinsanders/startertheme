<?php

$_lang['moddevtools'] = 'modDevTools';
$_lang['moddevtools_menu_desc'] = 'Удобное управление элементами';
$_lang['moddevtools_chunks_intro'] = 'Вы можете напрямую редактировать чанки, содержащиеся в шаблоне.';
$_lang['moddevtools_snippets_intro'] = 'Вы можете напрямую редактировать сниппеты, содержащиеся в шаблоне.';
$_lang['moddevtools_templates_intro'] = 'Вы можете напрямую редактировать шаблоны, которые содержат этот чанк.';
$_lang['moddevtools_res_template_intro'] = 'В таблице выводятся ресурсы с данным шаблоном.';
$_lang['moddevtools_res_chunk_intro'] = 'В таблице выводятся ресурсы, в контенте или шаблоне которых содержится этот чанк.';
$_lang['moddevtools_res_snippet_intro'] = 'В таблице выводятся ресурсы, в контенте или шаблоне которых вызывается этот сниппет.';
$_lang['moddevtools_grid_actions'] = 'Действия';
$_lang['moddevtools_template_change'] = 'Изменить шаблон';
$_lang['moddevtools_search_desc'] = 'Поиск и замена строк в шаблонах и чанках.';
$_lang['moddevtools_text_to_find'] = 'Искать текст';
$_lang['moddevtools_replace'] = 'Заменить';
$_lang['moddevtools_replace_all'] = 'Заменить все';
$_lang['moddevtools_replace_with'] = 'Заменить на';
$_lang['moddevtools_find'] = 'Найти';
$_lang['moddevtools_skip'] = 'Пропустить';
$_lang['moddevtools_notfound'] = 'Ничего не найдено!';
$_lang['moddevtools_search_filters'] = 'Искать только в элементах';