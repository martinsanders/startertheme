<?php
require_once (dirname(dirname(__FILE__)) . '/moddevtoolslink.class.php');
class modDevToolsLink_mysql extends modDevToolsLink {}