--------------------
modDevTools
--------------------
Author: Kireev Vitaly <kireevvit@gmail.com>
--------------------

Rapid site development helper for MODx Revolution.

Feel free to suggest ideas/improvements/bugs on GitHub: /
http://github.com/argnist/modDevTools/issues

If you would like to make a contribution, you can send a payment to kireevvit@gmail.com by PayPal


Дополнение, которое помогает разработчикам быстрее и проще работать в админке MODX Revolution

Об идеях, предложения и багах лучше писать на GitHub:
http://github.com/argnist/modDevTools/issues

Если вы хотите вознаградить автора за разработку, можно послать платеж через PayPal на почту kireevvit@gmail.com, или на Яндекс-кошелек 41001474467368