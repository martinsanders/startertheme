<?php
$_lang['seopro.keywords'] = 'Mots-clé';
$_lang['seopro.characters'] = 'Caractères';
$_lang['seopro.characters.allowed'] = 'Caractères autorisés';
$_lang['seopro.tips'] = 'Astuces SEO-PRO!';
$_lang['seopro.focuskeywords'] = 'Mots-clé principaux';
$_lang['seopro.focuskeywords_desc'] = 'Séparés par des virgules';
$_lang['seopro.prevbox'] = 'Dans Google ça donne quoi?';
$_lang['seopro.prevbox_yandex'] = 'Dans Yandex ça donne quoi?';
$_lang['seopro.emptymetadescription']='<i>Remplissez la description avant de prévisualiser</i>';
$_lang['seopro.branding_text']='This site is optimized with the Sterc seoPro plugin - https://github.com/Sterc/SEOPro.';

$_lang['setting_seopro.delimiter'] = 'Séparateur dans Google/Yandex preview.';
$_lang['setting_seopro.delimiter_desc'] = 'Séparateur de titre et de nom de site';
