<?php

namespace Elastica\Exception;

/**
 * General Elastica exception interface
 *
 * @category Xodoa
 * @package Elastica
 * @author Nicolas Ruflin <spam@ruflin.com>
 */
interface ExceptionInterface
{
}
